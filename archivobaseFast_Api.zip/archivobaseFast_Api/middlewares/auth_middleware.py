from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request

class AuthMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        # Aquí podrías agregar lógica para verificar tokens JWT o sesiones
        response = await call_next(request)
        return response
