from pydantic import BaseModel

class BookSchema(BaseModel):
    title: str
    author: str
    year: int
    category: str
    pages: int
    
    class Config:
        orm_mode = True