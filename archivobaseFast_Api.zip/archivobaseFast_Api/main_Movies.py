from fastapi import FastAPI
from routers.books import router as books_router
from middlewares.auth_middleware import AuthMiddleware

app = FastAPI(title="Biblioteca de la Maravilla", version="0.0.1")

# Agregar middlewares al pipeline de la aplicación
app.add_middleware(AuthMiddleware)

# Incluir routers de diferentes recursos
app.include_router(books_router, prefix="/books", tags=["Books"])

@app.get("/", tags=["Root"])
async def root():
    return {"message": "Bienvenido a la Biblioteca de la Maravilla!"}
