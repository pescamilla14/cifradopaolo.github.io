from jwt import decode, ExpiredSignatureError, InvalidTokenError, PyJWTError
from fastapi import HTTPException

def validate_token(token: str) -> dict:
    try:
        data: dict = decode(token, key="llavesita", algorithms=['HS256'])
        return data
    except ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token has expired")
    except InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")
    except PyJWTError as e:
        # Esta captura cualquier otra excepción de JWT no cubierta explícitamente
        raise HTTPException(status_code=401, detail=str(e))
