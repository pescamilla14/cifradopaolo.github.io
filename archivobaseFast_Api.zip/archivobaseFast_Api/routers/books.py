#book.py
from fastapi import APIRouter, HTTPException, Depends
from models.book import Book
from sqlalchemy.orm import Session
from config.database import SessionLocalm
from schemas.book import BookSchema

router = APIRouter()

@router.get("/books/")
def read_books(skip: int = 0, limit: int = 10, db: Session = Depends(SessionLocalm)):
    books = db.query(Book).offset(skip).limit(limit).all()
    return books

@router.get("/books/{book_id}")
def get_book_by_id(book_id: int, db: Session = Depends(SessionLocalm)):
    book = db.query(Book).filter(Book.id == book_id).first()
    if book is None:
        raise HTTPException(status_code=404, detail="hmm al parecer no existe nada con ese id")
    return book

@router.get("/books/category/{category}")
def get_books_by_category(category: str, db: Session = Depends(SessionLocalm)):
    books = db.query(Book).filter(Book.category == category).all()
    return books

@router.delete("/books/{book_id}")
def delete_book(book_id: int, db: Session = Depends(SessionLocalm)):
    book = db.query(Book).get(book_id)
    if book is None:
        raise HTTPException(status_code=404, detail="al parecer no existe tu libro")
    db.delete(book)
    db.commit()
    return {"message": "tu libro fue borrado"}

@router.post("/books/")
def create_book(book: BookSchema, db: Session = Depends(SessionLocalm)):
    new_book = Book(**book.dict())
    db.add(new_book)
    db.commit()
    db.refresh(new_book)
    return new_book

@router.put("/books/{book_id}")
def update_book(book_id: int, book_update: BookSchema, db: Session = Depends(SessionLocalm)):
    book = db.query(Book).get(book_id)
    if book is None:
        raise HTTPException(status_code=404, detail="Book not found")
    for var, value in vars(book_update).items():
        setattr(book, var, value) if value else None
    db.commit()
    return book
